# CeTZ

CeTZ (CeTZ, ein Typst Zeichenpaket) is a library for drawing with [Typst](https://typst.app) with an API inspired by TikZ and [Processing](https://processing.org/).

## Examples

<!-- img width is set so the table gets evenly spaced by GitHub's css -->
<table>
<tr>
  <td>
    <a href="gallery/karls-picture.typ">
      <img src="gallery/karls-picture.png" width="250px" alt="Right triangle on the unit circle illustrating sine and cosine">
    </a>
  </td>
  <td>
    <a href="gallery/paciolis.typ">
      <img src="gallery/paciolis.png" width="250px" alt="Pacioli's construction of the icosahedron">
    </a>
  </td>
  <td>
    <a href="gallery/plate-capacitor.typ">
      <img src="gallery/plate-capacitor.png" width="250px" alt="Plate capacitor">
    </a>
  </td>
</tr>
<tr>
  <td>Karl's Picture</td>
  <td>Pacioli's construction of the icosahedron</td>
  <td>Plate Capacitor</td>
</tr>
<tr>
  <td>
    <a href="gallery/tree.typ">
      <img src="gallery/tree.png" width="250px" alt="Simple tree graph">
    </a>
  </td>
  <td>
    <a href="gallery/periodic-table.typ">
      <img src="gallery/periodic-table.png" width="250px" alt="Periodic table of elements">
    </a>
  </td>
  <td>
    <a href="gallery/waves.typ">
      <img src="gallery/waves.png" width="250px" alt="3D diagram showing two sine waves">
    </a>
  </td>
</tr>
<tr>
  <td>Tree Layout</td>
  <td>Periodic Table of Elements</td>
  <td>Waves</td>
</tr>
<tr>
  <td>
    <a href="gallery/torus.typ">
      <img src="gallery/torus.png" width="250px" alt="3D torus figure">
    </a>
  </td>
  <td>
  </td>
  <td>
  </td>
</tr>
<tr>
  <td>Torus</td>
  <td></td>
  <td></td>
</tr>
</table>

_Click on the example image to jump to the code._

You can explore an example gallery of scientific diagrams at [janosh.github.io/diagrams](https://janosh.github.io/diagrams).

## Usage

For information, see the [API Reference (PDF)](./manual.pdf?raw=true) or the [online manual](https://cetz-package.github.io/docs).

To use this package, simply add the following code to your document:

```typ
#import "@preview/cetz:0.5.2"

#cetz.canvas({
  import cetz.draw: *
  // Your drawing code goes here
})
```

## CeTZ Libraries

- [cetz-plot - Plotting and Charts Library](https://github.com/cetz-package/cetz-plot)
- [cetz-venn - Simple two- or three-set Venn diagrams](https://github.com/cetz-package/cetz-venn)

## Installing

To install the CeTZ package under [your local typst package dir](https://github.com/typst/packages?tab=readme-ov-file#local-packages) you can use the `install` script from the repository.

Make sure to first perform a recursive git clone

```bash
# to fetch a clean clone:
git clone --recursive https://github.com/cetz-package/cetz.git
# or if you forgot the `--recursive` flag before:
git submodule update --init
```

and also ensure you have `just` and `cargo` installed.

<details>
  <summary>For nix users</summary>

After enabling flakes, use:

```bash
nix --extra-experimental-features 'nix-command flakes' develop
```

</details>

Now use the installation script:

```bash
just install
```

The installed version can be imported by prefixing the package name with `@local`.

```typ
#import "@local/cetz:0.5.2"

#cetz.canvas({
  import cetz.draw: *
  // Your drawing code goes here
})
```

### Just

This project uses [just](https://github.com/casey/just), a handy command runner.

You can run all commands without having `just` installed, just have a look into the `justfile`.
To install `just` on your system, use your systems package manager. On Windows, [Cargo](https://doc.rust-lang.org/cargo/) (`cargo install just`), [Chocolatey](https://chocolatey.org/) (`choco install just`) and [some other sources](https://just.systems/man/en/packages.html) can be used. You need to run it from a `sh` compatible shell on Windows (e.g git-bash).

## Testing

This package comes with some unit tests under the `tests` directory.
To run all tests you can run the `just test` target. You need to have
[`tytanic`](https://github.com/tingerrr/tytanic/) in your `PATH`: `cargo install tytanic`.

## Projects using CeTZ

- [finite](https://github.com/jneug/typst-finite) Finite is a Typst package for rendering finite automata.
- [fletcher](https://github.com/Jollywatt/typst-fletcher) Package for drawing commutative diagrams and figures with arrows.
- [chronos](https://git.kb28.ch/HEL/chronos) Package for drawing sequence diagrams.
- [circuiteria](https://git.kb28.ch/HEL/circuiteria) Package for drawing circuits.
- [zap](https://codeberg.org/grangelouis/zap) Package for drawing standard electronic circuits.
- [bone](https://codeberg.org/grangelouis/bone)  Package to draw structural analysis and kinematic diagrams
- [rivet](https://git.kb28.ch/HEL/rivet-typst) Package for drawing instruction / register diagrams.
- [plotsy-3d](https://github.com/misskacie/plotsy-3d) Package for rendering 3D objects & plots.
- [alchemist](https://github.com/Typsium/alchemist) A package to render skeletal formulae using a human-readable format using cetz.
- [deckz](https://github.com/micheledusi/Deckz) Render Poker-Style playing cards.
- [neural-netz](https://github.com/edgaremy/neural-netz) Visualize neural network architectures.
- [energy-dia](https://github.com/Typsium/energy-dia) Library for creating professional energy diagrams in chemistry and physics.
- [conchord](https://github.com/sitandr/conchord) Package for writing lyrics with chords that generates fretboard diagrams.
